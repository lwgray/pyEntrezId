# PyEntrezId
Converts Ensembl Transcript Gene ID to Entrez Gene Id
